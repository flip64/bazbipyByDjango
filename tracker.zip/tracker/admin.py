from django.contrib import admin
from .models import WatchedURL,PriceHistory



admin.site.register(WatchedURL)
admin.site.register(PriceHistory)



